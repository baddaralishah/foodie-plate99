<?php
return[

    'ip2location' => [
        'local' => [
            'path' => database_path('ip2location/IP2LOCATION.BIN'),
        ],
    ],

];
