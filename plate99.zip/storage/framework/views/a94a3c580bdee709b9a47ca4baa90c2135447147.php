<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">All Users</a>
                </div>
                <div class="collapse navbar-collapse">
                </div>
            </div>
        </nav>
        <div class="content">
            <div class="row">
                <?php foreach($users as $user): ?>
                    <div class="col-md-4">
                        <div class="card card-user">
                            <div class="image">

                            </div>
                            <div class="content">
                                <div class="author">
                                    <a href="#">
                                        <img class="avatar border-gray" src="<?php echo e(asset('profileImages')."/".$user->image); ?>" alt="<?php echo e($user->name); ?>"/>

                                        <h4 class="title"><?php echo e($user->name); ?><br />
                                            <small><?php echo e($user->email); ?></small><br/>
                                            <small><?php echo e($user->contact); ?></small>
                                        </h4>
                                    </a>
                                </div>
                                <p class="description text-center"> <?php echo e($user->about); ?>

                                </p>
                                <p class="description text-center"> <?php echo e($user->address); ?>

                                </p>
                            </div>
                            <hr>
                            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/statusProfile/'.$user->id)); ?>">
                                <?php echo e(csrf_field()); ?>

                            &nbsp; <button class="btn btn-warning" type="submit"><?php echo $user->status?></button>
                            </form><br/>
                            <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/makeAdmin/'.$user->id)); ?>">
                                <?php echo e(csrf_field()); ?>

                                &nbsp; <button class="btn btn-info" type="submit"><?php echo $user->role?></button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
            </div>
        </div>
        <footer class="footer">
            <div class="container-fluid">

                <p class="copyright">
                    &copy; <script>document.write(new Date().getFullYear())</script> Design and Developed by <a href="https://github.com/baddaralishah">Badar Ali</a>
                </p>
            </div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminTemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>